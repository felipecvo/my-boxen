require 'spec_helper'

describe 'audacity' do
  it do
    should contain_package('Audacity').with({
      :source   => 'http://audacity.googlecode.com/files/audacity-macosx-ub-2.0.3.dmg',
      :provider => 'appdmg'
    })
  end
end
