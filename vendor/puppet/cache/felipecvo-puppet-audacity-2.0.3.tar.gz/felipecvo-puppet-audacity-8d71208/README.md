# Audacity Puppet Module for Boxen
[![Build
Status](https://travis-ci.org/felipecvo/puppet-audacity.png?branch=master)](https://travis-ci.org/felipecvo/puppet-audacity)

Install [Audacity](http://audacity.sourceforge.net/), a free,
easy-to-use and multilingual audio editor and recorder.

## Usage

```puppet
include audacity
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
